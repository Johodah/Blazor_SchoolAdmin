﻿
namespace SchoolAdmin
{
    internal class StudentAgeValidatorAttribute : Attribute
    {
    }
}