﻿namespace SchoolAdmin
{
    public class StudentAgeValidator
    {
    }
}
