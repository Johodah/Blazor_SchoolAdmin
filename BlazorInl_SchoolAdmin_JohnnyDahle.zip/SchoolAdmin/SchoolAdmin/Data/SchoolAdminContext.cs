﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SchoolAdmin;

namespace SchoolAdmin.Data
{
    public class SchoolAdminContext : DbContext
    {
        public SchoolAdminContext (DbContextOptions<SchoolAdminContext> options)
            : base(options)
        {
        }

        public DbSet<SchoolAdmin.Student> Student { get; set; } = default!;
    }
}
