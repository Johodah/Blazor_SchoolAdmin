﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolAdmin
{
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-ZåäöÅÄÖ-]*$", ErrorMessage = "Special characters or numbers are not accepted.")]
        public string? firstName { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-ZåäöÅÄÖ-]*$", ErrorMessage = "Special characters or numbers are not accepted.")]
        public string? lastName { get; set; }

        [Required, DataType(DataType.Date), AgeValidator(10)]

        public DateTime birthDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Ange email")]
        [EmailAddress(ErrorMessage = "E-postadressen är inte i ett giltigt format.")]
        public string? email { get; set; }

    }
}
